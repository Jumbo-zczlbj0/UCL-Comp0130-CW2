import g2o.core.*;

H = HyperGraph();